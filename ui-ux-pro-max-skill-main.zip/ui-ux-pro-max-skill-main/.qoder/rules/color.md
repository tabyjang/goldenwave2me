---
trigger: always_on
---

| No | Product Type | Keywords | Primary (Hex) | Secondary (Hex) | CTA (Hex) | Background (Hex) | Text (Hex) | Border (Hex) | Notes |
|-----|--------------|----------|---------------|-----------------|-----------|------------------|------------|--------------|-------|
| 1 | SaaS (General) | saas, general | #2563EB | #3B82F6 | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Trust blue + accent contrast |
| 2 | Micro SaaS | micro, saas | #2563EB | #3B82F6 | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Vibrant primary + white space |
| 3 | E-commerce | commerce | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Brand primary + success green |
| 4 | E-commerce Luxury | commerce, luxury | #1C1917 | #44403C | #CA8A04 | #FAFAF9 | #0C0A09 | #D6D3D1 | Premium colors + minimal accent |
| 5 | Service Landing Page | service, landing, page | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Brand primary + trust colors |
| 6 | B2B Service | b2b, service | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Professional blue + neutral grey |
| 7 | Financial Dashboard | financial, dashboard | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark bg + red/green alerts + trust blue |
| 8 | Analytics Dashboard | analytics, dashboard | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Cool→Hot gradients + neutral grey |
| 9 | Healthcare App | healthcare, app | #0891B2 | #22D3EE | #059669 | #ECFEFF | #164E63 | #A5F3FC | Calm blue + health green + trust |
| 10 | Educational App | educational, app | #4F46E5 | #818CF8 | #F97316 | #EEF2FF | #1E1B4B | #C7D2FE | Playful colors + clear hierarchy |
| 11 | Creative Agency | creative, agency | #EC4899 | #F472B6 | #06B6D4 | #FDF2F8 | #831843 | #FBCFE8 | Bold primaries + artistic freedom |
| 12 | Portfolio/Personal | portfolio, personal | #18181B | #3F3F46 | #2563EB | #FAFAFA | #09090B | #E4E4E7 | Brand primary + artistic interpretation |
| 13 | Gaming | gaming | #7C3AED | #A78BFA | #F43F5E | #0F0F23 | #E2E8F0 | #4C1D95 | Vibrant + neon + immersive colors |
| 14 | Government/Public Service | government, public, service | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Professional blue + high contrast |
| 15 | Fintech/Crypto | fintech, crypto | #F59E0B | #FBBF24 | #8B5CF6 | #0F172A | #F8FAFC | #334155 | Dark tech colors + trust + vibrant accents |
| 16 | Social Media App | social, media, app | #2563EB | #60A5FA | #F43F5E | #F8FAFC | #1E293B | #DBEAFE | Vibrant + engagement colors |
| 17 | Productivity Tool | productivity, tool | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Clear hierarchy + functional colors |
| 18 | Design System/Component Library | design, system, component, library | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Clear hierarchy + code-like structure |
| 19 | AI/Chatbot Platform | chatbot, platform | #7C3AED | #A78BFA | #06B6D4 | #FAF5FF | #1E1B4B | #DDD6FE | Neutral + AI Purple (#6366F1) |
| 20 | NFT/Web3 Platform | nft, web3, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark + Neon + Gold (#FFD700) |
| 21 | Creator Economy Platform | creator, economy, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Vibrant + Brand colors |
| 22 | Sustainability/ESG Platform | sustainability, esg, platform | #7C3AED | #A78BFA | #06B6D4 | #FAF5FF | #1E1B4B | #DDD6FE | Green (#228B22) + Earth tones |
| 23 | Remote Work/Collaboration Tool | remote, work, collaboration, tool | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Calm Blue + Neutral grey |
| 24 | Mental Health App | mental, health, app | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Calm Pastels + Trust colors |
| 25 | Pet Tech App | pet, tech, app | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Playful + Warm colors |
| 26 | Smart Home/IoT Dashboard | smart, home, iot, dashboard | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark + Status indicator colors |
| 27 | EV/Charging Ecosystem | charging, ecosystem | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Electric Blue (#009CD1) + Green |
| 28 | Subscription Box Service | subscription, box, service | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Brand + Excitement colors |
| 29 | Podcast Platform | podcast, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark + Audio waveform accents |
| 30 | Dating App | dating, app | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Warm + Romantic (Pink/Red gradients) |
| 31 | Micro-Credentials/Badges Platform | micro, credentials, badges, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Trust Blue + Gold (#FFD700) |
| 32 | Knowledge Base/Documentation | knowledge, base, documentation | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Clean hierarchy + minimal color |
| 33 | Hyperlocal Services | hyperlocal, services | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Location markers + Trust colors |
| 34 | Beauty/Spa/Wellness Service | beauty, spa, wellness, service | #10B981 | #34D399 | #8B5CF6 | #ECFDF5 | #064E3B | #A7F3D0 | Soft pastels (Pink #FFB6C1 Sage #90EE90) + Cream + Gold accents |
| 35 | Luxury/Premium Brand | luxury, premium, brand | #1C1917 | #44403C | #CA8A04 | #FAFAF9 | #0C0A09 | #D6D3D1 | Black + Gold (#FFD700) + White + Minimal accent |
| 36 | Restaurant/Food Service | restaurant, food, service | #DC2626 | #F87171 | #CA8A04 | #FEF2F2 | #450A0A | #FECACA | Warm colors (Orange Red Brown) + appetizing imagery |
| 37 | Fitness/Gym App | fitness, gym, app | #DC2626 | #F87171 | #16A34A | #FEF2F2 | #1F2937 | #FECACA | Energetic (Orange #FF6B35 Electric Blue) + Dark bg |
| 38 | Real Estate/Property | real, estate, property | #0F766E | #14B8A6 | #0369A1 | #F0FDFA | #134E4A | #99F6E4 | Trust Blue (#0077B6) + Gold accents + White |
| 39 | Travel/Tourism Agency | travel, tourism, agency | #EC4899 | #F472B6 | #06B6D4 | #FDF2F8 | #831843 | #FBCFE8 | Vibrant destination colors + Sky Blue + Warm accents |
| 40 | Hotel/Hospitality | hotel, hospitality | #1E3A8A | #3B82F6 | #CA8A04 | #F8FAFC | #1E40AF | #BFDBFE | Warm neutrals + Gold (#D4AF37) + Brand accent |
| 41 | Wedding/Event Planning | wedding, event, planning | #7C3AED | #A78BFA | #F97316 | #FAF5FF | #4C1D95 | #DDD6FE | Soft Pink (#FFD6E0) + Gold + Cream + Sage |
| 42 | Legal Services | legal, services | #1E3A8A | #1E40AF | #B45309 | #F8FAFC | #0F172A | #CBD5E1 | Navy Blue (#1E3A5F) + Gold + White |
| 43 | Insurance Platform | insurance, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Trust Blue (#0066CC) + Green (security) + Neutral |
| 44 | Banking/Traditional Finance | banking, traditional, finance | #0F766E | #14B8A6 | #0369A1 | #F0FDFA | #134E4A | #99F6E4 | Navy (#0A1628) + Trust Blue + Gold accents |
| 45 | Online Course/E-learning | online, course, learning | #0D9488 | #2DD4BF | #EA580C | #F0FDFA | #134E4A | #5EEAD4 | Vibrant learning colors + Progress green |
| 46 | Non-profit/Charity | non, profit, charity | #0891B2 | #22D3EE | #F97316 | #ECFEFF | #164E63 | #A5F3FC | Cause-related colors + Trust + Warm |
| 47 | Music Streaming | music, streaming | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark (#121212) + Vibrant accents + Album art colors |
| 48 | Video Streaming/OTT | video, streaming, ott | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark bg + Content poster colors + Brand accent |
| 49 | Job Board/Recruitment | job, board, recruitment | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Professional Blue + Success Green + Neutral |
| 50 | Marketplace (P2P) | marketplace, p2p | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Trust colors + Category colors + Success green |
| 51 | Logistics/Delivery | logistics, delivery | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Blue (#2563EB) + Orange (tracking) + Green (delivered) |
| 52 | Agriculture/Farm Tech | agriculture, farm, tech | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Earth Green (#4A7C23) + Brown + Sky Blue |
| 53 | Construction/Architecture | construction, architecture | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Grey (#4A4A4A) + Orange (safety) + Blueprint Blue |
| 54 | Automotive/Car Dealership | automotive, car, dealership | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Brand colors + Metallic accents + Dark/Light |
| 55 | Photography Studio | photography, studio | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Black + White + Minimal accent |
| 56 | Coworking Space | coworking, space | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Energetic colors + Wood tones + Brand accent |
| 57 | Cleaning Service | cleaning, service | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Fresh Blue (#00B4D8) + Clean White + Green |
| 58 | Home Services (Plumber/Electrician) | home, services, plumber, electrician | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Trust Blue + Safety Orange + Professional grey |
| 59 | Childcare/Daycare | childcare, daycare | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Playful pastels + Safe colors + Warm accents |
| 60 | Senior Care/Elderly | senior, care, elderly | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Calm Blue + Warm neutrals + Large text |
| 61 | Medical Clinic | medical, clinic | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Medical Blue (#0077B6) + Trust White + Calm Green |
| 62 | Pharmacy/Drug Store | pharmacy, drug, store | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Pharmacy Green + Trust Blue + Clean White |
| 63 | Dental Practice | dental, practice | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Fresh Blue + White + Smile Yellow accent |
| 64 | Veterinary Clinic | veterinary, clinic | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Caring Blue + Pet-friendly colors + Warm accents |
| 65 | Florist/Plant Shop | florist, plant, shop | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Natural Green + Floral pinks/purples + Earth tones |
| 66 | Bakery/Cafe | bakery, cafe | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Warm Brown + Cream + Appetizing accents |
| 67 | Coffee Shop | coffee, shop | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Coffee Brown (#6F4E37) + Cream + Warm accents |
| 68 | Brewery/Winery | brewery, winery | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Deep amber/burgundy + Gold + Craft aesthetic |
| 69 | Airline | airline | #7C3AED | #A78BFA | #06B6D4 | #FAF5FF | #1E1B4B | #DDD6FE | Sky Blue + Brand colors + Trust accents |
| 70 | News/Media Platform | news, media, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Brand colors + High contrast + Category colors |
| 71 | Magazine/Blog | magazine, blog | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Editorial colors + Brand primary + Clean white |
| 72 | Freelancer Platform | freelancer, platform | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Professional Blue + Success Green + Neutral |
| 73 | Consulting Firm | consulting, firm | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Navy + Gold + Professional grey |
| 74 | Marketing Agency | marketing, agency | #EC4899 | #F472B6 | #06B6D4 | #FDF2F8 | #831843 | #FBCFE8 | Bold brand colors + Creative freedom |
| 75 | Event Management | event, management | #7C3AED | #A78BFA | #F97316 | #FAF5FF | #4C1D95 | #DDD6FE | Event theme colors + Excitement accents |
| 76 | Conference/Webinar Platform | conference, webinar, platform | #0F172A | #334155 | #0369A1 | #F8FAFC | #020617 | #E2E8F0 | Professional Blue + Video accent + Brand |
| 77 | Membership/Community | membership, community | #7C3AED | #A78BFA | #F97316 | #FAF5FF | #4C1D95 | #DDD6FE | Community brand colors + Engagement accents |
| 78 | Newsletter Platform | newsletter, platform | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Brand primary + Clean white + CTA accent |
| 79 | Digital Products/Downloads | digital, products, downloads | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Product category colors + Brand + Success green |
| 80 | Church/Religious Organization | church, religious, organization | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Warm Gold + Deep Purple/Blue + White |
| 81 | Sports Team/Club | sports, team, club | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Team colors + Energetic accents |
| 82 | Museum/Gallery | museum, gallery | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Art-appropriate neutrals + Exhibition accents |
| 83 | Theater/Cinema | theater, cinema | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Dark + Spotlight accents + Gold |
| 84 | Language Learning App | language, learning, app | #0D9488 | #2DD4BF | #EA580C | #F0FDFA | #134E4A | #5EEAD4 | Playful colors + Progress indicators + Country flags |
| 85 | Coding Bootcamp | coding, bootcamp | #3B82F6 | #60A5FA | #F97316 | #F8FAFC | #1E293B | #E2E8F0 | Code editor colors + Brand + Success green |
| 86 | Cybersecurity Platform | cybersecurity, security, cyber, hacker | #00FF41 | #0D0D0D | #00FF41 | #000000 | #E0E0E0 | #1F1F1F | Matrix Green + Deep Black + Terminal feel |
| 87 | Developer Tool / IDE | developer, tool, ide, code, dev | #3B82F6 | #1E293B | #2563EB | #0F172A | #F1F5F9 | #334155 | Dark syntax theme colors + Blue focus |
| 88 | Biotech / Life Sciences | biotech, science, biology, medical | #0EA5E9 | #0284C7 | #10B981 | #F8FAFC | #0F172A | #E2E8F0 | Sterile White + DNA Blue + Life Green |
| 89 | Space Tech / Aerospace | space, aerospace, tech, futuristic | #FFFFFF | #94A3B8 | #3B82F6 | #0B0B10 | #F8FAFC | #1E293B | Deep Space Black + Star White + Metallic |
| 90 | Architecture / Interior | architecture, interior, design, luxury | #171717 | #404040 | #D4AF37 | #FFFFFF | #171717 | #E5E5E5 | Monochrome + Gold Accent + High Imagery |
| 91 | Quantum Computing | quantum, qubit, tech | #00FFFF | #7B61FF | #FF00FF | #050510 | #E0E0FF | #333344 | Interference patterns + Neon + Deep Dark |
| 92 | Biohacking / Longevity | bio, health, science | #FF4D4D | #4D94FF | #00E676 | #F5F5F7 | #1C1C1E | #E5E5EA | Biological red/blue + Clinical white |
| 93 | Autonomous Systems | drone, robot, fleet | #00FF41 | #008F11 | #FF3333 | #0D1117 | #E6EDF3 | #30363D | Terminal Green + Tactical Dark |
| 94 | Generative AI Art | art, gen-ai, creative | #111111 | #333333 | #FFFFFF | #FAFAFA | #000000 | #E5E5E5 | Canvas Neutral + High Contrast |
| 95 | Spatial / Vision OS | spatial, glass, vision | #FFFFFF | #E5E5E5 | #007AFF | #888888 | #000000 | #FFFFFF | Glass opacity 20% + System Blue |
| 96 | Climate Tech | climate, green, energy | #2E8B57 | #87CEEB | #FFD700 | #F0FFF4 | #1A3320 | #C6E6C6 | Nature Green + Solar Yellow + Air Blue |